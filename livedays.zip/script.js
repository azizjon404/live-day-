function startCalculation() {
    let birthDate = document.getElementById("birthDate").value;
    if (!birthDate) {
        alert("Введите дату рождения!");
        return;
    }
    document.getElementById("result").classList.add("hidden");
    document.getElementById("loader").classList.remove("hidden");

    setTimeout(() => {
        let birth = new Date(birthDate);
        let today = new Date();
        let diffTime = today - birth;
        let diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        document.getElementById("loader").classList.add("hidden");
        document.getElementById("result").classList.remove("hidden");
        document.getElementById("result").innerText = "Вы прожили " + diffDays + " дней.";
    }, 10000);
}
